package com.tkcoolbar.app;

import android.content.*;import android.database.sqlite.*;import android.database.*;import java.util.*;

public class DB extends SQLiteOpenHelper {
 public DB(Context c){super(c,"tkcoolbar.db",null,1);} 
 public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT NOT NULL,credit REAL DEFAULT 0,used REAL DEFAULT 0,created INTEGER)");d.execSQL("CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_id INTEGER,type TEXT,amount REAL,balance REAL,note TEXT,created INTEGER)");d.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT)");d.execSQL("INSERT INTO settings(k,v) VALUES('shop','TK Cool Bar')");d.execSQL("INSERT INTO settings(k,v) VALUES('sms','1')");}
 public void onUpgrade(SQLiteDatabase d,int o,int n){}
 public long addCustomer(String n,String p){ContentValues v=new ContentValues();v.put("name",n);v.put("phone",p);v.put("created",System.currentTimeMillis());return getWritableDatabase().insert("customers",null,v);}
 public Cursor customers(){return getReadableDatabase().rawQuery("SELECT * FROM customers ORDER BY name",null);}
 public Cursor customer(long id){return getReadableDatabase().rawQuery("SELECT * FROM customers WHERE id=?",new String[]{""+id});}
 public double balance(long id){Cursor c=customer(id);double x=0;if(c.moveToFirst())x=c.getDouble(c.getColumnIndexOrThrow("credit"))-c.getDouble(c.getColumnIndexOrThrow("used"));c.close();return x;}
 public boolean addTx(long cid,String type,double amt,String note){SQLiteDatabase d=getWritableDatabase();double b=balance(cid);ContentValues v=new ContentValues();v.put("id",cid);if(type.equals("ADVANCE")){d.execSQL("UPDATE customers SET credit=credit+? WHERE id=?",new Object[]{amt,cid});b+=amt;}else{if(amt>b)return false;d.execSQL("UPDATE customers SET used=used+? WHERE id=?",new Object[]{amt,cid});b-=amt;}v.clear();v.put("customer_id",cid);v.put("type",type);v.put("amount",amt);v.put("balance",b);v.put("note",note);v.put("created",System.currentTimeMillis());d.insert("tx",null,v);return true;}
 public Cursor tx(){return getReadableDatabase().rawQuery("SELECT tx.*,customers.name,customers.phone FROM tx JOIN customers ON customers.id=tx.customer_id ORDER BY tx.id DESC",null);}
 public int customerCount(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM customers",null);c.moveToFirst();int n=c.getInt(0);c.close();return n;}
 public double totalBalance(){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(credit-used),0) FROM customers",null);c.moveToFirst();double n=c.getDouble(0);c.close();return n;}
}
