# TK Cool Bar Android App

Current module includes:
- Customer database
- Advance / credit balance
- Purchase deduction
- Transaction history
- Automatic SMS attempt after every saved transaction (requires Android SEND_SMS permission)
- Red/white TK Cool Bar UI
- GitHub Actions workflow to build APK

Important: WhatsApp does not permit an ordinary Android app to silently send messages in the background. The production version should use WhatsApp's supported share flow or an approved business messaging API.
